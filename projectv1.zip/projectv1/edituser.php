<?php

// include config
include('config.php');

// include functions
include('functions.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	// get username and password
	$fullname = $_POST['fullname'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	// query database
	$sql = file_get_contents('sql/updateUsers.sql');
	$params = array(
		'fullname' => $fullname,
		'username' => $username,
		'password' => $password
	);
	$statement = $database->prepare($sql);
	$statement->execute($params);
	
	header('location: index.php');
}

?>

<!doctype html>

<head>
  <title>Edit Account</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <link rel="stylesheet" type="text/css" href="css/style.css" title="style" />
</head>

<body>
  <div id="main">
	    <div id="header">
	      <div id="logo">
	        <div id="logo_text">
	          <!-- class="logo_colour", allows you to change the colour of the text -->
	          <h1><a href="index.php">Collab Call</a></h1>
	          <h2>Making Better Music Together</h2>
	        </div>
	      </div>
	      <div id="menubar">
	        <ul id="menu">
	          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
	          <li><a href="index.php">Home</a></li>
	          <li><a href="createpost.php">Create Post</a></li>
	          <li><a href="viewpost.php">Your Posts</a></li>
	          <li class="selected"><a href="edituser.php"><?php echo $user['fullname'] ?></a></li>
	          <li><a href="logout.php">Log Out</a></li>
	        </ul>
	      </div>
	    </div>
	    <div id="site_content">
	    	<div id="content">
	        <!-- insert the page content here -->
		        <h1>Edit User</h1>
				<form method="POST">
					<input type="text" name="fullname" value="<?php echo $user['fullname'] ?>" />
					<br>
					<input readonly type="text" name="username" value="<?php echo $user['username'] ?>" />
					<br>
					<input type="password" name="password" value="<?php echo $user['fullname'] ?>" />
					<br>
					<input type="submit" value="Update Account" />
				</form>
			</div>
		</div>
		<div id="footer">
	      Jacob Nordheim
	    </div>
	</div>
</body>
</html>