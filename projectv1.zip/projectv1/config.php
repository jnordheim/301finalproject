<?php

// Connecting to the MySQL database
$DB_USER = "nordheimj2";
$DB_PASSWORD = "r&85FiHi";

$database = new PDO('mysql:host=csweb.hh.nku.edu;dbname=db_fall18_nordheimj2', $DB_USER, $DB_PASSWORD);
$database->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Autoloader
function my_autoloader($class) {
    include('class.' . $class . '.php');
}

spl_autoload_register('my_autoloader');

// Start the session
session_start();

$current_url = basename($_SERVER['REQUEST_URI']);

// Redirect if user ID is not set and not on login.php
if (!isset($_SESSION["userID"]) && $current_url != 'login.php' ) {
    if ($current_url = 'createuser.php' ) {
    	;
    }

    else {
    	header("Location: login.php");
    }
}

// Else if get user ID
elseif (isset($_SESSION["userID"])) {
	$sql = file_get_contents('sql/getUsers.sql');
	$params = array(
		'userid' => $_SESSION["userID"]
	);
	$statement = $database->prepare($sql);
	$statement->execute($params);
	$users = $statement->fetchAll(PDO::FETCH_ASSOC);
	
	$user = $users[0];
}
