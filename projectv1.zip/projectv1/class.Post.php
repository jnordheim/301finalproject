<?php

class Post {
    public $postnumber;
    public $database;

    function __construct() {

    }

    function deletePost ($postnumber, $database) {
        $this->postnumber = $postnumber;
        $this->database = $database;

        $sql = file_get_contents('sql/deletePost.sql');
        $params = array(
            'postnumber' => $postnumber
        );
        $statement = $database->prepare($sql);
        $statement->execute($params);
    }
}