<?php

// include
include('config.php');

// include functions
include('functions.php');

// get search term from URL using the get function
$term = get('search-term');

//search function
$posts = searchPosts($term, $database);


?>

<!doctype html>

<head>
  <title>Home Page</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <link rel="stylesheet" type="text/css" href="css/style.css" title="style" />
</head>

<body>
  <div id="main">
	    <div id="header">
	      <div id="logo">
	        <div id="logo_text">
	          <!-- class="logo_colour", allows you to change the colour of the text -->
	          <h1><a href="index.php">Collab Call</a></h1>
	          <h2>Making Better Music Together</h2>
	        </div>
	      </div>
	      <div id="menubar">
	        <ul id="menu">
	          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
	          <li class="selected"><a href="index.php">Home</a></li>
	          <li><a href="createpost.php">Create Post</a></li>
	          <li><a href="viewpost.php">Your Posts</a></li>
	          <li><a href="edituser.php"><?php echo $user['fullname'] ?></a></li>
	          <li><a href="logout.php">Log Out</a></li>
	        </ul>
	      </div>
	    </div>
	    <div id="site_content">
	    	<div id="content">
	        <!-- insert the page content here -->
		        <br>
		        <center>
		        <form method="GET">
					<input type="text" name="search-term" placeholder="Search Posts" />
					<input type="submit" />
				</form>
				</center>
				<?php foreach($posts as $post) : ?>
					<h3>
						<?php echo $post['header']; ?>
					</h3>
					<h4>
						<?php echo $post['username']; ?> <br />
						<?php echo $post['time']; ?> <br />
					</h4>
					<p>
						<?php echo $post['description']; ?> <br />
						<?php echo $post['link']; ?> <br />
					</p>
				<?php endforeach; ?>
			</div>
		</div>
		<div id="footer">
	      <a href="hiddenpage.php">Jacob Nordheim</a>
	    </div>
	</div>
</body>
</html>