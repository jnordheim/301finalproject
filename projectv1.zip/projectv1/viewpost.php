<?php

// include
include('config.php');

// include functions
include('functions.php');

$sql = file_get_contents('sql/getUserPosts.sql');
$params = array(
	'fullname' => $user['fullname']
);
$statement = $database->prepare($sql);
$statement->execute($params);
$posts = $statement->fetchAll(PDO::FETCH_ASSOC);


?>

<!doctype html>

<head>
  <title>User Posts</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <link rel="stylesheet" type="text/css" href="css/style.css" title="style" />
</head>

<body>
  <div id="main">
	    <div id="header">
	      <div id="logo">
	        <div id="logo_text">
	          <!-- class="logo_colour", allows you to change the colour of the text -->
	          <h1><a href="index.php">Collab Call</a></h1>
	          <h2>Making Better Music Together</h2>
	        </div>
	      </div>
	      <div id="menubar">
	        <ul id="menu">
	          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
	          <li ><a href="index.php">Home</a></li>
	          <li><a href="createpost.php">Create Post</a></li>
	          <li class="selected"><a href="viewpost.php">Your Posts</a></li>
	          <li><a href="edituser.php"><?php echo $user['fullname'] ?></a></li>
	          <li><a href="logout.php">Log Out</a></li>
	        </ul>
	      </div>
	    </div>
	    <div id="site_content">
	    	<div id="content">
	        <!-- insert the page content here -->
		        <br>
		        <center>
		        
				</center>
				<?php foreach($posts as $post) : ?>
					<h3>
						<?php echo $post['header']; ?>
					</h3>
					<h4>
						<?php echo $post['time']; ?> <br />
					</h4>
					<p>
						<?php echo $post['description']; ?> <br />
						<?php echo $post['link']; ?> <br /><br />
						<a href="deletepost.php?postnumber=<?php echo $post['postnumber'] ?>">Delete Post</a>
					</p>
				<?php endforeach; ?>
			</div>
		</div>
		<div id="footer">
	      Jacob Nordheim
	    </div>
	</div>
</body>
</html>