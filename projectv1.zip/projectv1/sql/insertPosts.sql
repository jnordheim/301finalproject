INSERT INTO posts (header, username, description, link, userid)
VALUES(:header, :username, :description, :link, :userid)