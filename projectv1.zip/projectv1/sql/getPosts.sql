SELECT *
FROM posts
WHERE header LIKE :term
ORDER BY time desc