INSERT INTO users (fullname, username, password)
VALUES(:fullname, :username, :password)
