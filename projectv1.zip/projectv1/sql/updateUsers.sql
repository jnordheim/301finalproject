UPDATE users
SET fullname = :fullname, username = :username, password = :password
WHERE username = :username