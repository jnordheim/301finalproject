SELECT *
FROM jacoblist