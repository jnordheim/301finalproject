SELECT *
FROM posts
JOIN users on posts.userid = users.userid
WHERE fullname = :fullname
ORDER BY time desc