/* Select users where the userid is equal to a passed user id */
SELECT *
FROM users
WHERE userid = :userid