DELETE FROM posts
WHERE postnumber = :postnumber