<?php

// include config
include('config.php');

// include functions
include('functions.php');

// If form submitted:
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	// get username and password
	$header = $_POST['header'];
	$username = $_POST['username'];
	$description = $_POST['description'];
	$link = $_POST['link'];
	$userid = $_POST['userid'];

	
	// query database
	$sql = file_get_contents('sql/insertPosts.sql');
	$params = array(
		'header' => $header,
		'username' => $username,
		'description' => $description,
		'link' => $link,
		'userid' => $userid
	);
	$statement = $database->prepare($sql);
	$statement->execute($params);
	
	header('location: index.php');
	die();
}

?>

<!doctype html>

<head>
  <title>Create Post</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <link rel="stylesheet" type="text/css" href="css/style.css" title="style" />
  <script src='https://cloud.tinymce.com/stable/tinymce.min.js'></script>
  <script>
  tinymce.init({
    selector: "textarea"
  });
  </script>
</head>

<body>
  <div id="main">
	    <div id="header">
	      <div id="logo">
	        <div id="logo_text">
	          <!-- class="logo_colour", allows you to change the colour of the text -->
	          <h1><a href="index.php">Collab Call</a></h1>
	          <h2>Making Better Music Together</h2>
	        </div>
	      </div>
	      <div id="menubar">
	        <ul id="menu">
	          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
	          <li><a href="index.php">Home</a></li>
	          <li class="selected"><a href="createpost.php">Create Post</a></li>
	          <li><a href="viewpost.php">Your Posts</a></li>
	          <li><a href="edituser.php"><?php echo $user['fullname'] ?></a></li>
	          <li><a href="logout.php">Log Out</a></li>
	        </ul>
	      </div>
	    </div>
	    <div id="site_content">
	    	<div id="content">
	        <!-- insert the page content here -->
		        <h1>Create Post</h1>
				<form method="POST">
					<input type="text" name="header" placeholder="Subject" />
					<br>
					<input type="hidden" name="username" value="<?php echo $user['username'] ?>">
					<br>
					<textarea name="description">Description</textarea>
					<br>
					<input type="text" name="link" placeholder="The Link of Project" />
					<br>
					<input type="hidden" name="userid" value="<?php echo $user['userid'] ?>">
					<br>
					<input type="submit" value="Create Post" />
				</form>
			</div>
		</div>
		<div id="footer">
	      Jacob Nordheim
	    </div>
	</div>
</body>
</html>