<?php

// include config
include('config.php');

// include functions
include('functions.php');

// if form submitted:
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	// get username and password
	$fullname = $_POST['fullname'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	// query database
	$sql = file_get_contents('sql/insertUsers.sql');
	$params = array(
		'fullname' => $fullname,
		'username' => $username,
		'password' => $password
	);
	$statement = $database->prepare($sql);
	$statement->execute($params);
	
	header('location: login.php');
	die();
}

?>

<!doctype html>

<head>
  <title>Create User</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <link rel="stylesheet" type="text/css" href="css/style.css" title="style" />
</head>

<body>
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
          <!-- class="logo_colour", allows you to change the colour of the text -->
          <h1><a href="index.php">Collab Call</a></h1>
          <h2>Making Better Music Together</h2>
        </div>
      </div>
      
    </div>
    <div id="site_content">
      
      <div id="content">
        <!-- insert the page content here -->
        <h1>Create User</h1>
		<form method="POST">
			<input type="text" name="fullname" placeholder="Full Name" />
			<br>
			<input type="text" name="username" placeholder="Username" />
			<br>
			<input type="password" name="password" placeholder="Password" />
			<br>
			<input type="submit" value="Create User" />
		</form>
      </div>
    </div>
    <div id="footer">
      Jacob Nordheim
    </div>
  </div>
</body>
</html>